# Hello World

This is a simple Hello World program in Python.

## How to run
```bash
python hello.py
```